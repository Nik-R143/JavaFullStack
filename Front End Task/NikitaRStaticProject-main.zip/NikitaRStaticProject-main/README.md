# NikitaRStaticProject
Static Web Project 2021
